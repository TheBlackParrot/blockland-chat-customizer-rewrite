function serverCmdCCHandshake(%client, %version) {
	%client.hasCC = 1;
	echo(%client.name SPC "has Client_CustomChat" SPC %version);
}

package CCStringOverridePackage {
	function GameConnection::autoAdminCheck(%this) {
		commandToClient(%this, 'CCHandshake');
		return parent::autoAdminCheck(%this);
	}

	function serverCmdMessageSent(%client, %msg) {
		if(%client.hasCC) {
			if($Pref::Server::CustomChat::EnableOverride) {
				commandToClient(%client, 'CCStringOverride', (%client.CCOverrideData $= "" ? $Pref::Server::CustomChat::Override : %client.CCOverrideData));
			} else {
				commandToClient(%client, 'CCStringOverride', "");
			}
		}
		return parent::serverCmdMessageSent(%client, %msg);
	}
};
if($Pref::Server::CustomChat::EnableOverride) {
	activatePackage(CCStringOverridePackage);
}